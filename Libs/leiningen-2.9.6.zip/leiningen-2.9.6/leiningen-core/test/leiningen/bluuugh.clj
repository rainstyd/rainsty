(ns leiningen.bluuugh
  "Dummy task for tests.")

(defn ^:no-project-needed bluuugh
  [project]
  (println "This is a dummy task for tests."))