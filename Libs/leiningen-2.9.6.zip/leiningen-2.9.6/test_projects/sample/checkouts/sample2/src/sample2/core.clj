(ns sample2.core
  (:require sample2.alt)
  (:gen-class))
