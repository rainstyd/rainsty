(ns bad-require.core
  (:require [this.namespace.does.not.exist]))

(defn -main [])
