(ns sample-ordered-aot.baz)

(defn baz
  "I don't do a whole lot."
  [x]
  (println x "Hello, World!"))
