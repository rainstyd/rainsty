(defproject with-classifiers "0.1.0-SNAPSHOT"
  :classifiers {:tests {:source-paths ^:replace ["test"]
                        :resource-paths ^:replace []}})
