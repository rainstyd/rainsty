(defproject java-main "0.1.0-SNAPSHOT"
  :java-source-paths ["src/java"]
  :dependencies [[org.clojure/clojure "1.8.0"]] ;; lein run errors if not there.
  :main my.java.Main)
