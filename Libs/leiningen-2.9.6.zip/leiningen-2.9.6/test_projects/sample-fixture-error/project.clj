(defproject sample-fixture-error "0.1.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.8.0"]])
