(defproject lein-test-reload-bug "0.1.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.10.1"]])
