(defproject lein-pprint "1.3.2"
  :description "Pretty-print a representation of the project map."
  :url "https://github.com/technomancy/leiningen"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :eval-in-leiningen true)
