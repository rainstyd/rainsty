The [tutorial has moved](https://github.com/technomancy/leiningen/blob/master/doc/TUTORIAL.md)!
