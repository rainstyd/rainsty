(ns sample2.alt)
