(ns nom.nom.check
  (:require [sample2.core])
  (:gen-class))

(defn -main [])
