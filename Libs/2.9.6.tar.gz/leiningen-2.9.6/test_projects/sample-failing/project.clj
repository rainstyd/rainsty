(defproject nomnomnom "0.5.0-SNAPSHOT"
  :dependencies [[~(symbol "org.clojure" "clojure") ~"1.2.0"]]
  :aot [nom.nom.nom])
