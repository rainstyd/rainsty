# Introduction to more-gen-classes

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
