(ns more-gen-classes.baz
  (:gen-class))
