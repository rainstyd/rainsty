(defproject lein-test-exit-code "0.1.0-SNAPSHOT"
  :dependencies [[org.clojure/clojure "1.10.1"]]
  :eval-in :leiningen)
