(defproject project-with-aliases "0.1.0-SNAPSHOT"
  :a 1
  :profiles {:a2 {:a 2}})
