{:user
 {:aliases {"echo" ["with-profile" "+a2" "echo"]
            "project" ["with-profile" "+a2" "project"]
            "projecta" ["with-profile" "+a2" "project" "a"]
            "project-set" ["with-profile" "a2" "project"]
            "projecta-set" ["with-profile" "a2" "project" "a"]}}}
