(defproject overlapped-sourcepaths "0.1.0"
  :dependencies [[org.clojure/clojure "1.3.0"]]
  :java-source-paths ["src"])
