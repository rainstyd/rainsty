(defproject checkout-lib2 "0.0.1"
  :description "Test some checkouts.")
