(ns leiningen.sirius)

(defn ^:pass-through-help sirius [project & args] args)
