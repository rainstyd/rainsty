(ns leiningen.zero "Dummy task for tests.")

(defn zero [project]
  (println "a dummy task for tests"))
