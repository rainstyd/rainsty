{:user {:plugins [[lein-pprint "1.1.1"]]}}
