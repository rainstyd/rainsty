package nrepl;

public class QuotaExceeded extends Throwable {

}
