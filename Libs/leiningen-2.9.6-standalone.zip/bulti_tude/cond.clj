(ns bulti-tude.cond
  "This ns seems to be necessary to make leiningen add \"test/bulti_tude/\" to the classpath")

