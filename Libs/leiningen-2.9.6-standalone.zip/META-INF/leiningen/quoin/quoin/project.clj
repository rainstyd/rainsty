(defproject quoin "0.1.2"
  :description "Template engine support and utilities"
  :url "http://github.com/davidsantiago/quoin"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :dependencies [[org.clojure/clojure "1.3.0"]])
